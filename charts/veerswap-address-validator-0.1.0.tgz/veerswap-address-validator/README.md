# VeerSwap Multi-Chain Address & Memo Validator

A lightweight, non-custodial cross-chain cryptocurrency address format, checksum, and Memo / Destination Tag validation service packaged for Kubernetes via Helm.

## Overview

Before sending funds on a non-custodial deposit-address swap, validating network compatibility and required Memo / Destination Tag fields prevents irreversible cross-chain transfer mistakes.

### Verified VeerSwap Flow Rules

- **No wallet connection & no registration/KYC**: Quote and create swaps directly via [VeerSwap](https://veerswap.com/) and [VeerSwap Exchange](https://veerswap.com/exchange).
- **Live reference quote**: Step 1 displays a live reference estimate (not locked); the quote refreshes after entering the receiving address and refund method.
- **Deposit-address execution**: Send a single deposit to the generated order deposit address within the active window (`15-minute` for EVM / Solana assets, `60-minute` for PoW assets such as BTC / LTC).
- **Transparent fee**: Service fee up to `0.25%`.

## Documentation & Official Channels

- **Website**: https://veerswap.com/
- **Wrong Network Guide**: https://veerswap.com/guides/wrong-network
- **Memo & Destination Tag Guide**: https://veerswap.com/guides/memo-and-tag
- **GitHub Source**: https://github.com/naonao7k7k-cloud/multichain-memo-address-validator
- **X (Twitter)**: https://x.com/veerswap
- **Medium**: https://medium.com/@veerswap-official
- **Telegram**: https://t.me/veerswap
